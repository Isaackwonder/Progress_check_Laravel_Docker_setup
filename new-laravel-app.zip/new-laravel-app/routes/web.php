<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentRegistrationController;

// Home (optional landing page)
Route::get('/', function () {
    return view('home'); // Create resources/views/home.blade.php if needed
})->name('home');

// Show registration form
Route::get('/register', function () {
    return view('register'); // resources/views/register.blade.php
})->name('student.register.form');

// Handle form submission (Create)
Route::post('/register', [StudentRegistrationController::class, 'register'])->name('student.register');

// List all students (Read)
Route::get('/students', [StudentRegistrationController::class, 'showAll'])->name('student.list');

// Show edit form for a student (Update - view)
Route::get('/students/{id}/edit', [StudentRegistrationController::class, 'edit'])->name('student.edit');

// Handle update request (Update - action)
Route::post('/students/{id}/update', [StudentRegistrationController::class, 'update'])->name('student.update');

// Handle delete request (Delete)
Route::delete('/students/{id}', [StudentRegistrationController::class, 'destroy'])->name('student.delete');
