<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentRegistrationController;

// Homepage
Route::get('/', function () {
    return view('home');
})->name('home');

Route::get('/register', function () {
    return view('register');
})->name('student.register.form');

Route::post('/register', [StudentRegistrationController::class, 'register'])->name('student.register');
Route::get('/students', [StudentRegistrationController::class, 'showAll'])->name('student.list');
