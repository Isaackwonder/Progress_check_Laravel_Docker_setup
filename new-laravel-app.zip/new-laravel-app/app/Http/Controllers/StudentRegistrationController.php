<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\StudentRegistration;

class StudentRegistrationController extends Controller
{
    public function register(Request $request)
    {
        $validated = $request->validate([
            'username' => 'required|string|unique:student_registrations',
            'password' => 'required|string|min:6',
        ]);

        StudentRegistration::create($validated);

        return redirect()->back()->with('success', 'Student registered successfully!');
    }

    public function showAll()
    {
        $students = StudentRegistration::all();
        return view('students', compact('students'));
    }

    public function edit($id)
    {
        $student = StudentRegistration::findOrFail($id);
        return view('edit', compact('student'));
    }

    public function update(Request $request, $id)
    {
        $student = StudentRegistration::findOrFail($id);

        $validated = $request->validate([
            'username' => 'required|string|unique:student_registrations,username,' . $student->id,
            'password' => 'nullable|string|min:6',
        ]);

        $student->username = $validated['username'];
        if (!empty($validated['password'])) {
            $student->password = bcrypt($validated['password']);
        }
        $student->save();

        return redirect()->route('student.list')->with('success', 'Student updated successfully!');
    }

    public function destroy($id)
    {
        StudentRegistration::destroy($id);
        return redirect()->route('student.list')->with('success', 'Student deleted.');
    }
}
