<!-- resources/views/home.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Welcome to the Student Registration Portal</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-5 text-center">
    <h1 class="mb-4">Student Registration Portal</h1>
    <p class="lead">Use the options below to register or view registered students.</p>

    <a href="{{ route('student.register.form') }}" class="btn btn-primary btn-lg me-3">Register a Student</a>
    <a href="{{ route('student.list') }}" class="btn btn-secondary btn-lg">View Registered Students</a>
</div>
</body>
</html>
